# Electricity Demand Forecasting 

To ensure the better electric grid operation adn utility resourse planning, accurate electric energy demand forecasting is necessary. To enhance the grid resilience and energy security, the demand forecast should account for the extreme weather events also. As the world understood the need for utilising the natural energy sources, PV and solar grid installation also should be considered for accurate forecasting. 

In this project, first, a simple Linear Regression model is considered as a baseline model, and then the model is improved by considering multi seasonality and lag values of energy used. Final model uses XGBoost algorithm and the corresponding performance measures are: 

* R2 score = 0.99
* RMSE = 47.44
* MAPE = 1.44 %

This demonstrate an improvement of 0.33 in R2 score, a decrease of 6.8 % in MAPE, and a decrease of 207.54 in RMSE value,  from the baseline model. 

**Data Description:** *To develop the Electricity demand forecasting model, this project uses the Energy consumption data of SanDiego for the years 2014 to 2018, and the corresponding weather data from San Diego Airport weather station and PV installation data of SanDiego for the corresponding years is used.*

**Assumptions:** *This project is done by assuming that, the PV installation data and weather data are available in future, without any forecasting requirement. But in real time, it is required to forecast these also. However, simply subsituting the values for weather and PV installation related variables, using the already forecasted values will ensure the performance of the model developed in this work.* 


## Exploratory Data Analysis

* How does energy consumption vary across any particular day , averaged over the entire period??
* Monthly average load profile variations??
* Effect of temperature on energy consumption???
* Does the average monthly consumption values have increased over the years?
* how the energy consumption varies for weekdays vs the weekends or the holidays?
* Does increasing number of solar installations behind the customer meter resulted in a decrease in total energy consumption?



```python
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import scipy

import warnings
warnings.filterwarnings('ignore')
```


```python
df=pd.read_csv('energy_forecast_data.csv')
```


```python
df.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Dates</th>
      <th>SDGE</th>
      <th>Date</th>
      <th>year</th>
      <th>month</th>
      <th>day</th>
      <th>hour</th>
      <th>weekday</th>
      <th>season</th>
      <th>holiday</th>
      <th>non_working</th>
      <th>STATION</th>
      <th>DailyCoolingDegreeDays</th>
      <th>DailyHeatingDegreeDays</th>
      <th>HourlyDryBulbTemperature</th>
      <th>AC_kW</th>
      <th>cum_AC_kW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2014-01-01 00:00:00</td>
      <td>2096.0</td>
      <td>2014-01-01</td>
      <td>2014</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>Wednesday</td>
      <td>winter</td>
      <td>1</td>
      <td>non-working</td>
      <td>72290023188</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>51.0</td>
      <td>0.0</td>
      <td>220992.227</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2014-01-01 01:00:00</td>
      <td>1986.0</td>
      <td>2014-01-01</td>
      <td>2014</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Wednesday</td>
      <td>winter</td>
      <td>1</td>
      <td>non-working</td>
      <td>72290023188</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>51.5</td>
      <td>0.0</td>
      <td>220992.227</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2014-01-01 02:00:00</td>
      <td>1936.0</td>
      <td>2014-01-01</td>
      <td>2014</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>Wednesday</td>
      <td>winter</td>
      <td>1</td>
      <td>non-working</td>
      <td>72290023188</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>51.8</td>
      <td>0.0</td>
      <td>220992.227</td>
    </tr>
  </tbody>
</table>
</div>



### Exploring the Energy Data

#### Average hourly energy consumption 


```python
f1=df.groupby('hour')['SDGE'].mean().plot(figsize=(10,5))
plt.xlabel('Hour')
plt.ylabel('Average energy consumption (MWH) ')
plt.title('Hourly Energy Consumption(2014-2018)')
plt.xticks(df['hour'].unique())
plt.show()
```


    
![png](output_5_0.png)
    


Energy consumption peaks at evening. 04.00 PM to 8.00 PM is the interval that has high energy consumption.

#### Average monthly load profile 


```python
f1 = df.groupby('month')['SDGE'].mean().plot(figsize=(10,5))
plt.xlabel('Months')
plt.ylabel('Average energy consumption (MWH) ')
plt.title('Monthly Average Energy Consumption(2014-2018)')
plt.xticks(df['month'].unique())
plt.show()
```


    
![png](output_8_0.png)
    


Rapid increase in energy consumption from june and it attains peak value at August and then starts decreasing. June, July , august and september are the months which have higher consumption.

#### Monthly Trend


```python
df_months = df.groupby(['month','year'])[['SDGE']].mean()
df_months = pd.DataFrame(df_months)
df_month=df_months.unstack(level='month').reset_index()
df_month.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th>year</th>
      <th colspan="12" halign="left">SDGE</th>
    </tr>
    <tr>
      <th>month</th>
      <th></th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>10</th>
      <th>11</th>
      <th>12</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2014</td>
      <td>2289.122312</td>
      <td>2287.229167</td>
      <td>2237.892473</td>
      <td>2256.341667</td>
      <td>2435.094086</td>
      <td>2416.908333</td>
      <td>2756.000000</td>
      <td>2803.717742</td>
      <td>2939.491667</td>
      <td>2521.405914</td>
      <td>2231.704167</td>
      <td>2308.564516</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015</td>
      <td>2255.966398</td>
      <td>2205.293155</td>
      <td>2258.916667</td>
      <td>2196.484722</td>
      <td>2146.177419</td>
      <td>2412.219444</td>
      <td>2578.725806</td>
      <td>2848.950269</td>
      <td>2955.175000</td>
      <td>2656.813172</td>
      <td>2252.494444</td>
      <td>2372.629032</td>
    </tr>
  </tbody>
</table>
</div>




```python
melt_df = pd.melt(df_month, id_vars='year', value_name='Average monthly energy consumption in MWH')
melt_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>NaN</th>
      <th>month</th>
      <th>Average monthly energy consumption in MWH</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2014</td>
      <td>SDGE</td>
      <td>1</td>
      <td>2289.122312</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015</td>
      <td>SDGE</td>
      <td>1</td>
      <td>2255.966398</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016</td>
      <td>SDGE</td>
      <td>1</td>
      <td>2298.233871</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2017</td>
      <td>SDGE</td>
      <td>1</td>
      <td>2239.989221</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2018</td>
      <td>SDGE</td>
      <td>1</td>
      <td>2175.139451</td>
    </tr>
  </tbody>
</table>
</div>




```python
f2 = sns.FacetGrid(melt_df, col="month", margin_titles = True, col_wrap = 4)
f2.map(plt.scatter, "year", "Average monthly energy consumption in MWH");
f2.set_axis_labels("Years", "Avg. monthly MWH ");
f2.set(ylim=(melt_df['Average monthly energy consumption in MWH'].min() - 100, melt_df['Average monthly energy consumption in MWH'].max() + 100));
```


    
![png](output_12_0.png)
    


Average monthly Energy consumption decreases as the year passes, except for July and August

#### Weekly Trend
Average consumption for a particular hour over the week is considered.


```python
#new pivot table , where index is hour and columns are the week days.
week_df = df.pivot_table(index='hour',columns='weekday',values='SDGE',aggfunc='mean')
#week_df
```


```python
#plotting heatmap
f3 =plt.figure(figsize=(15,10))
sns.heatmap(week_df)
```




    <AxesSubplot:xlabel='weekday', ylabel='hour'>




    
![png](output_15_1.png)
    


* Energy consumption is less on weekend days
* For all weekdays, energy consumption is high from 8 to 20, and it is peak at interval 17 to 20.

#### Overall Energy Consumption Distribution


```python
f4=plt.figure(figsize=(10,8))
sns.distplot(df['SDGE'],kde=True,hist=False)
plt.xlabel('Overall Energy Consumption in MWH')
plt.title('Overall Energy Consumption Distribution (2014-2018)')
```




    Text(0.5, 1.0, 'Overall Energy Consumption Distribution (2014-2018)')




    
![png](output_17_1.png)
    


Most of the days have an energy consumption of the range around 1700 - 2600 MWH

### Exploring Energy and Temperature data together

#### Temperature v/s Energy Consumption


```python
plt.figure(figsize=(12,7))
sns.regplot(x= 'SDGE', y= 'HourlyDryBulbTemperature' , data= df) # linear regression plot
plt.xlabel('Energy consumption MWH')
plt.title('Temperature vs Energy consumption')
```




    Text(0.5, 1.0, 'Temperature vs Energy consumption')




    
![png](output_19_1.png)
    


#### Temperature v/s Energy Consumption for Summer 


```python
plt.figure(figsize=(12,7))
sns.regplot(x= 'SDGE', y= 'HourlyDryBulbTemperature' , data= df[df['season'] == 'summer' ]) 
plt.xlabel('Energy consumption MWH')
plt.title('Temperature vs Energy consumption for summmer')
```




    Text(0.5, 1.0, 'Temperature vs Energy consumption for summmer')




    
![png](output_21_1.png)
    


#### Temperature v/s Energy Consumption for Winter


```python
plt.figure(figsize=(12,7))
sns.regplot(x= 'SDGE', y= 'HourlyDryBulbTemperature' , data= df[df['season'] == 'winter' ]) 
plt.xlabel('Energy consumption MWH')
plt.title('Temperature vs Energy consumption for winter')
```




    Text(0.5, 1.0, 'Temperature vs Energy consumption for winter')




    
![png](output_23_1.png)
    


Energy consumption is more linearly varying with the temperature data in summer, comparing woth winter

### Exploring Energy and PV installation Data Together


```python
sns.lineplot(df['year'],df['cum_AC_kW'])
plt.title('Solar installed capacity')
plt.xticks(df['year'].unique())
plt.show()
```


    
![png](output_25_0.png)
    



```python
daylight_hours = np.arange(10, 17) # 10 am to 5 pm is considered, as the sunlight available time
for season in df['season'].unique():
    corrcoef, pvalue = scipy.stats.pearsonr(df[(df['season'] == season) & (df['hour'].isin(daylight_hours))]\
                                            ['SDGE'],df[(df['season'] == season) & (df['hour'].isin(daylight_hours))]\
                                            ['cum_AC_kW'])
    print(' pearson correlation coefficient and pvalue for '+season, corrcoef, round(pvalue, 4))
```

     pearson correlation coefficient and pvalue for winter -0.46943200615703995 0.0
     pearson correlation coefficient and pvalue for summer -0.31540493662809566 0.0
    

***There is no much difference, because solar panles work more efficiently in colder temperature. As a whole, it is almost equal energy may be produced over winter and summer season, there will not be much difference.***
